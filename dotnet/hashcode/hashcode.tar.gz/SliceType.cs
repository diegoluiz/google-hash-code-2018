namespace hashcode
{
    public class SliceType
    {
        public int RowsCount { get; set; }
        public int ColsCount { get; set; }

    }
}
