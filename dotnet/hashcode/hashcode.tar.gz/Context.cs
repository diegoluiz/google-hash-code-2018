namespace hashcode
{
    public static class Context{
        
        public static int minIngredients;
        public static int maxItems;

    }
}
